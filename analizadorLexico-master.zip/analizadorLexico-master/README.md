# Analizador Lexico
Aplicacion JAVA para analisis Lexico


#Caracteristicas

- Interface Gráfica para Analizar expresiones aritméticas.
- Panel izquierdo consiste en un editor de texto para introducir las expresiones que se van a validar. La cantidad máxima de expresiones que podrá evaluar su programa son 10.
- Panel Derecho consiste en el Visor de Resultados de los componentes léxicos (tokens) identificados por su programa.
- final de cada grupo de tokens, deberá notificar si la expresión es Válida o Incorrecta.  


##Integrantes
- Fernando Perez	13-1049
- Lorenzo Alejo		13-1087
- Luis Peralta		13-1071



##Datos Adicionales

- Materia: Teoria de Compiladores
- Profesor: Willis Polanco
- Universidad Iberoamericana (UNIBE)
- Junio 2015


